export const CONFIG = Object.freeze({
  API_URL: '',
  FALLBACK_URL: './data/fallback.json',
  ALLOW_FALLBACK: false,
  INITIAL_BATCH_SIZE: 12,
  LOAD_MORE_SIZE: 10,
  MIN_QUERY_LENGTH: 1,
  REQUEST_TIMEOUT_MS: 30000,
  CACHE_VERSION: '1',
});
